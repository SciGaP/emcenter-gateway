# IU Brand

This repository contains the different branding bar and footer assets to be applied to Indiana University websites. There are multiple versions within the `dist` directory:

- `3.2.x`
    - for IU Web Framework version `3.2.x`
    - for any non-WCMS, non-IU Web Framework websites
- `3.x`
    - for IU Web Framework version `3.x`
- `2.x`
    - for IU Communications Framework version `2.x`
- `1.x`
    - for framework version `1.x`
- `legacy`
    - for legacy versions of the framework

The IU Brand asset version `3.2.x` is the latest version and is intended to be used with sites not running on the IU Web Framework, or with IU Web Framework sites on version `3.2.x`.

## Version assets

Within each of the `iu-brand/dist/[version]` directories, you will find these assets:

- header-[campus].html
    - markup for the branding bar, including:
        - trident tab (`trident-large.png`)
        - campus name
- footer.html
    - markup for the footer, including:
        - tagline
        - formal signature (`iu-sig-formal.svg`)
        - copyright, accessibility, year
- brand.css
    - unminified styles for the branding bar and footer
- brand.min.css
    - minified styles for the branding bar and footer