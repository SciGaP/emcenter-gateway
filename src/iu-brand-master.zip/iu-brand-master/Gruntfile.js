const sass = require('node-sass');

module.exports = function(grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        secret: grunt.file.readJSON('secret.json'),

        versions: {
            dev: 'dev',
            legacy: '0.0.23',
            '1.x': '1.0.24',
            '2.x': '2.0.27',
            '3.x': '3.0.22',
            '3.2.x': '3.2.3'
        },

        id: 'iu',
        fullName: 'Indiana University',
        mediumName: 'Indiana University',
        shortName: 'Indiana University',
        url: 'https://www.iu.edu',

        rsync: {
            options: {
                args: ['--verbose', '--delete'],
                // an array of files you'd like to exclude; usual suspects...
                // exclude: ['.git*', 'cache', 'logs'],
                recursive: true,
                // what's the creds and host
                host: '<%= secret.iu_assets.username %>@<%= secret.iu_assets.host %>'
            },
            legacy: {
                options: {
                    // the dir you want to sync
                    src: './dist/legacy/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/<%= versions.legacy %>'
                }
            },
            "legacy-dev": {
                options: {
                    // the dir you want to sync
                    src: './dist/legacy/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/0.x-dev'
                }
            },
            "legacy-webtest": {
                options: {
                    // the dir you want to sync
                    src: './dist/legacy/',
                    // where should it be synced to on the remote host?
                    host: '<%= secret.iu_webtest.username %>@<%= secret.iu_webtest.host %>',
                    dest: '<%= secret.iu_webtest.dest %>/<%= versions["legacy"] %>'
                }
            },
            "1.x": {
                options: {
                    // the dir you want to sync
                    src: './dist/1.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/<%= versions["1.x"] %>'
                }
            },
            "1.x-webtest": {
                options: {
                    // the dir you want to sync
                    src: './dist/1.x/',
                    // where should it be synced to on the remote host?
                    host: '<%= secret.iu_webtest.username %>@<%= secret.iu_webtest.host %>',
                    dest: '<%= secret.iu_webtest.dest %>/<%= versions["1.x"] %>'
                }
            },
            "1.x-dev": {
                options: {
                    // the dir you want to sync
                    src: './dist/1.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/1.x-dev'
                }
            },
            "2.x": {
                options: {
                    // the dir you want to sync
                    src: './dist/2.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/<%= versions["2.x"] %>'
                }
            },
            "2.x-webtest": {
                options: {
                    // the dir you want to sync
                    src: './dist/2.x/',
                    // where should it be synced to on the remote host?
                    host: '<%= secret.iu_webtest.username %>@<%= secret.iu_webtest.host %>',
                    dest: '<%= secret.iu_webtest.dest %>/<%= versions["2.x"] %>'
                }
            },
            "2.x-dev": {
                options: {
                    // the dir you want to sync
                    src: './dist/2.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/2.x-dev'
                }
            },
            "3.x": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/<%= versions["3.x"] %>'
                }
            },
            "3.x-dev": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/3.x-dev'
                }
            },
            "3.x-webtest": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.x/',
                    // where should it be synced to on the remote host?
                    host: '<%= secret.iu_webtest.username %>@<%= secret.iu_webtest.host %>',
                    dest: '<%= secret.iu_webtest.dest %>/<%= versions["3.x"] %>'
                }
            },
            "3.2.x": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.2.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/<%= versions["3.2.x"] %>'
                }
            },
            "3.2.x-webtest": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.2.x/',
                    // where should it be synced to on the remote host?
                    host: '<%= secret.iu_webtest.username %>@<%= secret.iu_webtest.host %>',
                    dest: '<%= secret.iu_webtest.dest %>/<%= versions["3.2.x"] %>'
                }
            },
            "3.2.x-dev": {
                options: {
                    // the dir you want to sync
                    src: './dist/3.2.x/',
                    // where should it be synced to on the remote host?
                    dest: '<%= secret.iu_brand_assets.dest %>/3.2.x-dev'
                }
            },
        },

        codekit: {
            legacy: {
                files: [{
                    expand: true,
                    cwd: 'src/tmpl/legacy',
                    src: ['**/*.kit'],
                    dest: 'dist/legacy',
                    ext: '.html'
                }]
            },
            '1.x': {
                files: [{
                    expand: true,
                    cwd: 'src/tmpl/1.x',
                    src: ['**/*.kit'],
                    dest: 'dist/1.x',
                    ext: '.html'
                }]
            },
            '2.x': {
                files: [{
                    expand: true,
                    cwd: 'src/tmpl/2.x',
                    src: ['**/*.kit'],
                    dest: 'dist/2.x',
                    ext: '.html'
                }]
            },
            '3.x': {
                files: [{
                    expand: true,
                    cwd: 'src/tmpl/3.x',
                    src: ['**/*.kit'],
                    dest: 'dist/3.x',
                    ext: '.html'
                }]
            },
            '3.2.x': {
                files: [{
                    expand: true,
                    cwd: 'src/tmpl/3.2.x',
                    src: ['**/*.kit'],
                    dest: 'dist/3.2.x',
                    ext: '.html'
                }]
            }
        },

        replace: {
            options: {
                patterns: [
                    { match: 'id', replacement: '<%= id %>' },
                    { match: 'url', replacement: '<%= url %>' },
                    { match: 'full-name', replacement: '<%= fullName %>' },
                    { match: 'medium-name', replacement: '<%= mediumName %>' },
                    { match: 'short-name', replacement: '<%= shortName %>' }
                ]
            },
            legacy: {
                files: [{
                    src: 'dist/legacy/header.html',
                    dest: 'dist/legacy/header-<%= id %>.html',
                }]
            },
            '1.x': {
                files: [{
                    src: 'dist/1.x/header.html',
                    dest: 'dist/1.x/header-<%= id %>.html',
                }]
            },
            '2.x': {
                files: [{
                    src: 'dist/2.x/header.html',
                    dest: 'dist/2.x/header-<%= id %>.html',
                }]
            },
            '3.x': {
                files: [{
                    src: 'dist/3.x/header.html',
                    dest: 'dist/3.x/header-<%= id %>.html',
                }]
            },
            '3.2.x': {
                files: [{
                    src: 'dist/3.2.x/header.html',
                    dest: 'dist/3.2.x/header-<%= id %>.html',
                }]
            }
        },

        multi: {
            dist: {
                options: {
                    // logBegin: function( vars ){
                    //  grunt.log.writeln(vars.campus.id);
                    // },
                    // logEnd: function( vars ){
                    //  console.log( 'Page: ' + vars.campus.id + ' success');
                    // },
                    vars: {
                        campus: grunt.file.readJSON('campuses.json')
                    },
                    config: {
                        id: function( vars, rawConfig ){ return vars.campus.id; },
                        fullName: function( vars, rawConfig ){ return vars.campus.fullName; },
                        mediumName: function( vars, rawConfig ){ return vars.campus.mediumName; },
                        shortName: function( vars, rawConfig ){ return vars.campus.shortName; },
                        url: function( vars, rawConfig ){ return vars.campus.url; }
                    },
                    tasks: [ 'replace' ]
                }
            }
        },

        sass: {
            options: {
                implementation: sass,
                includePaths: [
                    'bower_components/bourbon/dist',
                    'bower_components/neat/app/assets/stylesheets',
                    'bower_components/foundation/scss'
                ],
                outputStyle: 'compressed',
                precision: 5
            },
            legacy: {
                files: {'dist/legacy/brand.min.css': 'src/scss/iu-brand-legacy.scss'}
            },
            'legacy-dev': {
                options: {
                    outputStyle: 'expanded'
                },
                files: {'dist/legacy/brand.css': 'src/scss/iu-brand-1.x.scss'}
            },
            '1.x': {
                files: {'dist/1.x/brand.min.css': 'src/scss/iu-brand-1.x.scss'}
            },
            '1.x-dev': {
                options: {
                    outputStyle: 'expanded'
                },
                files: {'dist/1.x/brand.css': 'src/scss/iu-brand-1.x.scss'}
            },
            '2.x': {
                files: {'dist/2.x/brand.min.css': 'src/scss/iu-brand-2.x.scss'}
            },
            '2.x-dev': {
                options: {
                    outputStyle: 'expanded'
                },
                files: {'dist/2.x/brand.css': 'src/scss/iu-brand-2.x.scss'}
            },
            '3.x': {
                files: {'dist/3.x/brand.min.css': 'src/scss/iu-brand-3.x.scss'}
            },
            '3.x-dev': {
                options: {
                    outputStyle: 'expanded'
                },
                files: {'dist/3.x/brand.css': 'src/scss/iu-brand-3.x.scss'}
            },
            '3.2.x-dev': {
                options: {
                    outputStyle: 'expanded'
                },
                files: {'dist/3.2.x/brand.css': 'src/scss/iu-brand-3.x.scss'}
            },
            '3.2.x': {
                files: {'dist/3.2.x/brand.min.css': 'src/scss/iu-brand-3.x.scss'}
            },
        },

        watch: {

            grunt: { files: ['Gruntfile.js'] },

            codekit: {
                files: ['src/tmpl/*/*.kit'], // watch all .kit files for changes
                tasks: ['codekit', 'replace', 'multi']
            },

            sass: {
                files: ['src/scss/**/*.scss'],
                tasks: ['sass']
            },
        }
    });

    grunt.loadNpmTasks('grunt-codekit');
    grunt.loadNpmTasks('grunt-sass');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-rsync');
    grunt.loadNpmTasks('grunt-replace')
    grunt.loadNpmTasks('grunt-multi');

    grunt.registerTask('deploy', ['rsync:dev']);
    grunt.registerTask('build', ['sass','codekit']);
    grunt.registerTask('default', ['build','watch']);
}
